See [Developer Setup](https://github.com/UprootLabs/gngr/wiki/Developer:Setup) for more information about how to use
these files.

File | Description
-----|------------
gngrDev.launch | contains the Eclipse launch configuration for running gngr.
EclipseJavaFormat_Spaced.xml | Format configuration for use with Eclipse. No Tabs and indent of 2 spaces.
