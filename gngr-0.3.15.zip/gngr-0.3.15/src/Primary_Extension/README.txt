This project is the default browser plugin. It includes
clientlets for HTML, XAMJ and various simple mime types.
The extension.properties file contains meta-information about
the extension.

This module is released under the GPL license.
