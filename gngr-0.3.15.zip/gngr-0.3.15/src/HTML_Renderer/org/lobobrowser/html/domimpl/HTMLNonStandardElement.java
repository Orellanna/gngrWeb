package org.lobobrowser.html.domimpl;

public class HTMLNonStandardElement extends HTMLElementImpl {
  public HTMLNonStandardElement(final String name, final boolean noStyleSheet) {
    super(name, noStyleSheet);
  }

  public HTMLNonStandardElement(final String name) {
    super(name);
  }
}
