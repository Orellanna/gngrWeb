package org.lobobrowser.html.domimpl;

public class HTMLGenericMarkupElement extends HTMLAbstractUIElement {
  public HTMLGenericMarkupElement(final String name) {
    super(name);
  }
}
