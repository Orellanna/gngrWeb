package org.lobobrowser.html.js;

/** Dummy implementation of Storage API */
final public class Storage {

  public String getItem(final String key) {
    return null;
  }
}
