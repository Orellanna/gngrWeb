package org.lobobrowser.main;

public enum OS {

  MAC, WINDOWS, UNIX, SOLARIS, UNKNOWN

}