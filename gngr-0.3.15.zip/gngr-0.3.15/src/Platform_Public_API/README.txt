This project is now the public API for platform access,
clientlets and plugin interfaces only. It is not tied
to any particular rendered language.

Note that this module, which has no dependencies on
other Lobo project modules, is released under a license
equivalent to the FreeBSD license. This is a permissive
license that is compatible with the GPL, according to
the FSF.
